let students = [];

function addStudent() {
    let name = prompt("Nhập tên sinh viên:");
    let age = Number(prompt("Nhập tuổi:"));
    let id = prompt("Nhập mã số sinh viên:");

    let student = {
        name: name,
        age: age,
        id: id
    };

    students.push(student);
    alert("Thêm sinh viên thành công!");
}

function showStudents() {
    if (students.length === 0) {
        console.log("Danh sách sinh viên trống");
        return;
    }

    console.log("Danh sách sinh viên:");

    for (let i = 0; i < students.length; i++) {
        console.log(
            "Tên: " + students[i].name +
            " | Tuổi: " + students[i].age +
            " | ID: " + students[i].id
        );
    }
}

function deleteStudent() {
    let deleteId = prompt("Nhập ID sinh viên cần xóa:");

    let found = false;

    for (let i = 0; i < students.length; i++) {
        if (students[i].id === deleteId) {
            students.splice(i, 1);
            found = true;
            alert("Xóa sinh viên thành công!");
            break;
        }
    }

    if (!found) {
        alert("Không tìm thấy sinh viên có ID này!");
    }
}

addStudent();
addStudent();

showStudents();

deleteStudent();

showStudents();
let input = prompt("Nhập dãy số bất kỳ, cách nhau bởi dấu cách");
let arr = input.split(" ");
arr.reverse();
console.log("Mảng sau khi đảo ngược:");
console.log(arr);
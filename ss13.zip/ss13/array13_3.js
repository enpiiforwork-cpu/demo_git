let input = prompt("Nhập dãy số bất kỳ, cách nhau bởi dấu cách");
let arr = input.split(" ");

let max = Number(arr[0]);

for (let i = 1; i < arr.length; i++) {
    if (Number(arr[i]) > max) {
        max = Number(arr[i]);
    }
}

alert("Phần tử lớn nhất trong mảng là: " + max);
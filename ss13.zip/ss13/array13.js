let arr = [];

while (arr.length < 10) {
    let randomNumber = Math.floor(Math.random() * 100); 
    arr.push(randomNumber);
}

console.log("Mảng gồm 10 phần tử ngẫu nhiên:");
console.log(arr);
let bingo = Number(prompt("Nhập 1 số bất kì từ 0 - 100 "));

let bingoNumber = [
    35,
    12,
    28,
    19,
    20
];

if (bingoNumber.includes(bingo)) {
    alert("Bingo");
} else {
    alert("Chúc bạn may mắn lần sau");
}
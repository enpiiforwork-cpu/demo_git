let arr = [];

let length = Math.floor(Math.random() * 11) + 10;

for (let i = 0; i < length; i++) {
    let randomNumber = Math.floor(Math.random() * 101);
    arr.push(randomNumber);
}

console.log("Mảng:", arr);

let sumOdd = 0;
let sumEven = 0;

for (let i = 0; i < arr.length; i++) {
    if (arr[i] % 2 === 0) {
        sumEven += arr[i];
    } else {
        sumOdd += arr[i];
    }
}

alert("Tổng các số chẵn là: " + sumEven);
alert("Tổng các số lẻ là: " + sumOdd);
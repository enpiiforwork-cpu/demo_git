let arr = [1, 5, 3, 5, 8, 5, 2, 9, 5, 7];
let k = Number(prompt("Nhập số nguyên k:"));

let count = 0;

for (let i = 0; i < arr.length; i++) {
    if (arr[i] === k) {
        count++;
    }
}

alert("Số " + k + " xuất hiện " + count + " lần trong mảng");

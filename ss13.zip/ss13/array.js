let menu = [
    "ca chi vang",
    "bo cuon",
    "ca bo",
    "Trâu gác bếp",
];

menu.push("Cas bof")
// thêm vào cuối list


menu.unshift("Thịt má heo")
// thêm vào đầu list

menu.splice


// nếu muốn xóa phần tử cuối cùng trong list
menu.pop()

menu.shift()
// muốn xóa phần tử đầu tiên trong list

// xóa hoặc thêm mới 1 phần tử vào trong vị trí bất kì trong list
menu.splice(2,1);
// 2 là vị trí bát đầu xóa, còn 1 là số lượng vị trí cần xóa ở đây là 1 thì chỉ xóa 1 phần tử thôi

menu.splice(2,0,"Quả cam")



//arr1.concar(arr2)
// nối 2 mảng với nhau
let newMenu = [
    "Bún bò huế",
    "Mỳ tôm",
    "Bún chả"
];
let concatMenu = menu.concat(newMenu);
console.log(concatMenu);

//array.indexOf(): tìm kiếm vị trí index của 1 phần tử trong mảng
menu.indexOf("Trâu gác bếp")
//=> Kết quả sẽ là 2 , nếu phần tử k có trong list thì kết quả sẽ ra là -1


//array.includes(el): Kiểm tra xem 1 phần tử có trong mảng hay k
// trả ra 2 giá trị true/false
menu.includes("Trâu cuốn lá lốt");

//array.reverse(): trả về ;ist nhưng thứ tự đc đảo ngc từ đău xuống cuối
menu.reverse()

let randomString = "hello world";
randomString.split("");
// chuỗi gốc đc tách thành mảng kí tự
let randomStringletters = randomString.split("");
// thành kiểu h e l l o kiểu như vậy

